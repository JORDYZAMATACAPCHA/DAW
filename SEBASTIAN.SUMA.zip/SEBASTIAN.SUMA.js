// ============================
// Juego de suma tipo 31
// ============================

const MAX_JUGADORES = 5;
let jugadores = []; // Array de jugadores {baraja, scoreElem, manoElem, eliminado}
let mazo;

// Inicializar el juego al cargar
resetGame();

// ============================
// Función para reiniciar todo
// ============================
function resetGame() {
    // Crear nuevo mazo
    mazo = new Baraja();
    mazo.addPokerCards();
    mazo.mezcla();

    // Crear jugadores
    crearJugadores(MAX_JUGADORES);

    // Repartir 2 cartas iniciales a cada jugador
    repartirInicial();
}

// ============================
// Crear jugadores dinámicamente
// ============================
function crearJugadores(cantidad) {
    jugadores = [];
    const contenedorJugadores = document.getElementById('jugadores');
    contenedorJugadores.innerHTML = '';

    for (let i = 0; i < cantidad; i++) {
        const baraja = new Baraja();
        const div = document.createElement('div');
        div.classList.add('jugador');
        div.innerHTML = `
            <h3>Jugador ${i + 1}: <span class="score">0 puntos</span></h3>
            <div class="mano"></div>
            <button onclick="pedirCarta(${i})">Pedir carta</button>
        `;
        contenedorJugadores.appendChild(div);

        jugadores.push({
            baraja: baraja,
            scoreElem: div.querySelector('.score'),
            manoElem: div.querySelector('.mano'),
            eliminado: false
        });
    }
}

// ============================
// Repartir cartas al inicio
// ============================
function repartirInicial() {
    for (let jugador of jugadores) {
        for (let i = 0; i < 2; i++) {
            repartir(jugador.baraja);
        }
    }
    actualizarPantalla();
}

// ============================
// Función para repartir cartas
// ============================
function repartir(jugadorBaraja, cantidad = 1) {
    for (let i = 0; i < cantidad; i++) {
        if (mazo.cartas.length > 0) {
            let carta = mazo.sacarCarta();
            carta.levantar();
            jugadorBaraja.meteCarta(carta);
        }
    }
}

// ============================
// Pedir carta a un jugador
// ============================
function pedirCarta(indiceJugador) {
    let jugador = jugadores[indiceJugador];
    if (jugador.eliminado) return;

    repartir(jugador.baraja);
    let puntos = calculaPuntos(jugador.baraja);

    // Revisar si se pasó de 31
    if (puntos > 31) {
        jugador.eliminado = true;
        alert(`Jugador ${indiceJugador + 1} se pasó de 31 y pierde!`);
        mostrarCartas(jugador.baraja, jugador.manoElem);
    }
    actualizarPantalla();
}

// ============================
// Mostrar cartas de un jugador
// ============================
function mostrarCartas(baraja, domElement) {
    for (let c of baraja.cartas) {
        c.levantar();
    }
    baraja.display(domElement);
}

// ============================
// Calcular puntos de una baraja
// ============================
function calculaPuntos(baraja) {
    let puntos = 0;
    for (let carta of baraja.cartas) {
        puntos += carta.valor;
    }
    return puntos;
}

// ============================
// Actualizar pantalla de todos los jugadores
// ============================
function actualizarPantalla() {
    for (let jugador of jugadores) {
        jugador.scoreElem.textContent = jugador.eliminado
            ? 'Perdió'
            : calculaPuntos(jugador.baraja) + ' puntos';
        jugador.baraja.display(jugador.manoElem);
    }

    // Mostrar mazo en mesa
    mazo.display(document.getElementById('mesa'));
}

// ============================
// Mezclar mazo
// ============================
function mezclar() {
    mazo.mezcla();
    actualizarPantalla();
}

// ============================
// Determinar ganador
// ============================
function determinarGanador() {
    let mejor = 0;
    let ganador = -1;

    for (let i = 0; i < jugadores.length; i++) {
        let jugador = jugadores[i];
        let puntos = calculaPuntos(jugador.baraja);

        if (!jugador.eliminado && puntos > mejor && puntos <= 31) {
            mejor = puntos;
            ganador = i;
        }
    }

    if (ganador >= 0) {
        alert(`¡Ganador es el Jugador ${ganador + 1} con ${mejor} puntos!`);
    } else {
        alert('Todos se pasaron, no hay ganador.');
    }

    // Mostrar cartas de todos los jugadores al final
    for (let jugador of jugadores) {
        mostrarCartas(jugador.baraja, jugador.manoElem);
    }
}
