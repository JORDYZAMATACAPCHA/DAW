package es.cifpcarlos3.testsfuncionales;

/**
 * @author Juan V. Carrillo
 */
public class Persona {
    private int edad;

    public Persona(int edad) {
        this.edad = edad;
    }

    public boolean isMayorDeEdad() {
        // La aserción detendrá la ejecución si la edad es negativa
        assert edad >= 0; 
        return edad >= 18;
    }
}