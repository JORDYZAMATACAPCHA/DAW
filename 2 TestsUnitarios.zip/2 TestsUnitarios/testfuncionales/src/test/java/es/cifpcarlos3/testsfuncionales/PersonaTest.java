package es.cifpcarlos3.testsfuncionales;

// IMPORTANTE: Estos son los imports de JUnit 5 (Jupiter)
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class PersonaTest {

    @Test
    public void test1_ValorNegativo() {
        Persona p = new Persona(-1);
        // assertThrows captura el error y verifica que sea el tipo esperado
        assertThrows(AssertionError.class, () -> p.isMayorDeEdad());
    }

    @Test
    public void test2_ValorNegativoGrande() {
        Persona p = new Persona(-100);
        assertThrows(AssertionError.class, () -> p.isMayorDeEdad());
    }

    @Test
    public void test3_ValorLimiteInferior() {
        Persona p = new Persona(0);
        assertFalse(p.isMayorDeEdad());
    }

    @Test
    public void test4_ValorLimiteMenor() {
        Persona p = new Persona(17);
        assertFalse(p.isMayorDeEdad());
    }

    @Test
    public void test5_ValorLimiteMayor() {
        Persona p = new Persona(18);
        assertTrue(p.isMayorDeEdad());
    }

    @Test
    public void test6_ValorLimiteSuperior() {
        Persona p = new Persona(100);
        assertTrue(p.isMayorDeEdad());
    }
}